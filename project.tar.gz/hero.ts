import { heroui } from "@heroui/react";

// Customize: heroui({ themes: { light: { colors: { primary: { DEFAULT: "#006FEE" } } }, dark: { colors: { primary: { DEFAULT: "#006FEE" } } } } })
export default heroui();
