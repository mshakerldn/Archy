"use client";

import { useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Chip,
  Divider,
  Input,
  Navbar,
  NavbarBrand,
  NavbarContent,
  Select,
  SelectItem,
  Textarea,
} from "@heroui/react";
import { motion } from "framer-motion";

// Dynamically import MapView with SSR disabled to avoid Leaflet SSR issues
const MapView = dynamic(() => import("./MapView"), {
  ssr: false,
  loading: () => (
    <div className="h-full w-full flex items-center justify-center bg-zinc-100">
      <p className="text-zinc-500">Loading map...</p>
    </div>
  ),
});

type Spot = {
  id: string;
  name: string;
  neighborhood: string;
  style: string;
  note: string;
  lat?: number;
  lng?: number;
};

const STYLE_OPTIONS = [
  "brutalist",
  "art deco",
  "gothic",
  "modernist",
  "neoclassical",
  "postmodern",
  "industrial",
  "vernacular",
];

export default function Home() {
  const [spots, setSpots] = useState<Spot[]>([]);
  const [form, setForm] = useState({
    name: "",
    neighborhood: "",
    style: "",
    note: "",
    lat: "",
    lng: "",
  });

  useEffect(() => {
    const raw = localStorage.getItem("archy_spots");
    if (raw) {
      try {
        setSpots(JSON.parse(raw));
      } catch {
        setSpots([]);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("archy_spots", JSON.stringify(spots));
  }, [spots]);

  const styleCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    spots.forEach((spot) => {
      counts[spot.style] = (counts[spot.style] || 0) + 1;
    });
    return counts;
  }, [spots]);

  const canAdd = form.name.trim().length > 0 && form.style.trim().length > 0;

  const handleAdd = () => {
    if (!canAdd) return;
    const lat = parseFloat(form.lat);
    const lng = parseFloat(form.lng);
    const hasCoords = Number.isFinite(lat) && Number.isFinite(lng);
    const next: Spot = {
      id: `${Date.now()}`,
      name: form.name.trim(),
      neighborhood: form.neighborhood.trim(),
      style: form.style.trim(),
      note: form.note.trim(),
      lat: hasCoords ? lat : undefined,
      lng: hasCoords ? lng : undefined,
    };
    setSpots((prev) => [next, ...prev]);
    setForm({ name: "", neighborhood: "", style: "", note: "", lat: "", lng: "" });
  };

  const mapCenter = useMemo<[number, number]>(() => {
    const withCoords = spots.find(
      (spot) => typeof spot.lat === "number" && typeof spot.lng === "number"
    );
    if (withCoords && withCoords.lat !== undefined && withCoords.lng !== undefined) {
      return [withCoords.lat, withCoords.lng];
    }
    const lat = parseFloat(form.lat);
    const lng = parseFloat(form.lng);
    if (Number.isFinite(lat) && Number.isFinite(lng)) {
      return [lat, lng];
    }
    return [40.7128, -74.006];
  }, [form.lat, form.lng, spots]);

  const mapPin = useMemo<[number, number] | null>(() => {
    const lat = parseFloat(form.lat);
    const lng = parseFloat(form.lng);
    return Number.isFinite(lat) && Number.isFinite(lng) ? [lat, lng] : null;
  }, [form.lat, form.lng]);


  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_#fff7ed_0%,_#fef3c7_28%,_#f8fafc_60%,_#fff_100%)] text-zinc-900">
      <Navbar className="bg-transparent">
        <NavbarBrand className="gap-2">
          <div className="h-9 w-9 rounded-xl bg-amber-200/70 flex items-center justify-center font-[family-name:var(--font-space-grotesk)] font-bold text-zinc-900">
            A
          </div>
          <span className="font-[family-name:var(--font-space-grotesk)] text-xl font-semibold">
            Archy
          </span>
        </NavbarBrand>
        <NavbarContent justify="end">
          <Chip className="bg-zinc-900 text-amber-100">collect the city</Chip>
        </NavbarContent>
      </Navbar>

      <main className="px-6 pb-16 pt-6 md:px-10">
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mx-auto flex max-w-6xl flex-col gap-4"
        >
          <h1 className="font-[family-name:var(--font-space-grotesk)] text-4xl sm:text-6xl font-bold tracking-tight">
            Archy
          </h1>
          <p className="text-lg sm:text-xl text-zinc-700">Collect the city.</p>
          <div className="flex flex-wrap gap-2">
            {[
              "unlock architecture spots",
              "earn style badges",
              "log notes from your walk",
            ].map((label) => (
              <Chip key={label} variant="flat" className="bg-amber-100 text-amber-900">
                {label}
              </Chip>
            ))}
          </div>
        </motion.section>

        <div className="mx-auto mt-10 grid max-w-6xl grid-cols-1 gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <Card className="bg-white/80 border border-amber-100 shadow-sm">
            <CardHeader className="flex flex-col items-start gap-2">
              <h2 className="font-[family-name:var(--font-space-grotesk)] text-2xl font-semibold">
                start a walk
              </h2>
              <p className="text-zinc-600">
                add a spot each time you find a building that feels special.
              </p>
            </CardHeader>
            <Divider className="bg-amber-100" />
            <CardBody className="gap-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <Input
                  label="spot name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
                <Input
                  label="neighborhood"
                  value={form.neighborhood}
                  onChange={(e) => setForm({ ...form, neighborhood: e.target.value })}
                />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Input
                  label="latitude"
                  placeholder="e.g. 40.7128"
                  value={form.lat}
                  onChange={(e) => setForm({ ...form, lat: e.target.value })}
                />
                <Input
                  label="longitude"
                  placeholder="e.g. -74.0060"
                  value={form.lng}
                  onChange={(e) => setForm({ ...form, lng: e.target.value })}
                />
              </div>
              <Select
                label="style badge"
                selectedKeys={form.style ? [form.style] : []}
                onSelectionChange={(keys) =>
                  setForm({ ...form, style: Array.from(keys)[0]?.toString() || "" })
                }
              >
                {STYLE_OPTIONS.map((style) => (
                  <SelectItem key={style}>
                    {style}
                  </SelectItem>
                ))}
              </Select>
              <Textarea
                label="notes"
                value={form.note}
                onChange={(e) => setForm({ ...form, note: e.target.value })}
                minRows={3}
              />
              <Button
                className="bg-zinc-900 text-amber-100"
                onPress={handleAdd}
                isDisabled={!canAdd}
              >
                add this spot
              </Button>
            </CardBody>
          </Card>

          <div className="flex flex-col gap-6">
            <Card className="bg-white/85 border border-amber-100 shadow-sm overflow-hidden">
              <CardHeader className="flex flex-col items-start gap-2">
                <h3 className="font-[family-name:var(--font-space-grotesk)] text-xl font-semibold">
                  pin it on the map
                </h3>
                <p className="text-zinc-600">
                  click the map to drop a pin, then add the spot.
                </p>
              </CardHeader>
              <Divider className="bg-amber-100" />
              <CardBody className="p-0">
                <div className="h-[340px] w-full">
                  <MapView
                    spots={spots}
                    mapCenter={mapCenter}
                    mapPin={mapPin}
                    onMapClick={(lat, lng) =>
                      setForm({
                        ...form,
                        lat: lat.toFixed(5),
                        lng: lng.toFixed(5),
                      })
                    }
                  />
                </div>
              </CardBody>
            </Card>
            <Card className="bg-white/85 border border-amber-100 shadow-sm">
              <CardHeader className="flex flex-col items-start gap-2">
                <h2 className="font-[family-name:var(--font-space-grotesk)] text-2xl font-semibold">
                  your collection
                </h2>
                <p className="text-zinc-600">
                  everything you have collected so far.
                </p>
              </CardHeader>
              <Divider className="bg-amber-100" />
              <CardBody className="gap-3">
                {spots.length === 0 ? (
                  <p className="text-zinc-500">no spots yet.</p>
                ) : (
                  spots.map((spot) => (
                    <div key={spot.id} className="rounded-xl border border-amber-100/80 p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-semibold">{spot.name}</span>
                        <Chip size="sm" className="bg-amber-100 text-amber-900">
                          {spot.style}
                        </Chip>
                      </div>
                      {spot.neighborhood && (
                        <p className="text-sm text-zinc-500">{spot.neighborhood}</p>
                      )}
                      {spot.note && <p className="text-sm text-zinc-700 mt-2">{spot.note}</p>}
                    </div>
                  ))
                )}
              </CardBody>
            </Card>

            <Card className="bg-white/85 border border-amber-100 shadow-sm">
              <CardHeader className="flex flex-col items-start gap-2">
                <h3 className="font-[family-name:var(--font-space-grotesk)] text-xl font-semibold">
                  style badges
                </h3>
                <p className="text-zinc-600">your current badge counts.</p>
              </CardHeader>
              <Divider className="bg-amber-100" />
              <CardBody className="flex flex-wrap gap-2">
                {Object.keys(styleCounts).length === 0 ? (
                  <p className="text-zinc-500">add your first spot to earn a badge.</p>
                ) : (
                  Object.entries(styleCounts).map(([style, count]) => (
                    <Chip key={style} className="bg-zinc-900 text-amber-100">
                      {style} · {count}
                    </Chip>
                  ))
                )}
              </CardBody>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
